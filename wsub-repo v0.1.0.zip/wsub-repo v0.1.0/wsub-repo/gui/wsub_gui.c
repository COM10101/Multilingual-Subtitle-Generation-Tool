/*
 * 编译 (MinGW-W64):
 *   windres wsub_gui.rc -O coff -o wsub_gui_res.o
 *   gcc -O2 -mwindows wsub_gui.c wsub_gui_res.o -o wsub_gui.exe -lcomctl32 -lcomdlg32 -lshell32 -lgdi32 -luser32
 */
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif

#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <shellapi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>

#define PATHCAP 2048

enum {
    CID_IN_EDIT = 101, CID_IN_BTN,
    CID_MODEL_EDIT,    CID_MODEL_BTN,
    CID_VAD_EDIT,      CID_VAD_BTN,
    CID_LANG, CID_BEAM, CID_THREADS,
    CID_START, CID_STOP, CID_OPEN,
    CID_STATUS, CID_PROGRESS, CID_LOG
};

#define WM_APP_LOG      (WM_APP + 1)
#define WM_APP_PROGRESS (WM_APP + 2)
#define WM_APP_DONE     (WM_APP + 3)

static HWND  g_hwnd;
static HWND  g_lbl[3], g_edit[3], g_btn[3];       // 输入 / 模型 / VAD
static HWND  g_lblLang, g_combo, g_lblBeam, g_beam, g_lblThr, g_threads;
static HWND  g_start, g_stop, g_open, g_status, g_prog, g_log;
static HFONT g_font, g_monoFont;
static int   g_dpi = 96;

static wchar_t g_dir[PATHCAP];        // 本程序所在目录
static wchar_t g_ini[PATHCAP];
static wchar_t g_lastOut[PATHCAP];    // 最近一次生成的字幕路径
static HANDLE  g_job;                 // 当前任务的Job Object，在界面线程访问
static BOOL    g_running, g_cancelled;

#define S(x) MulDiv((x), g_dpi, 96)

/* ================= 小工具 ================= */

static void clean_path(wchar_t *s)    // 去掉首尾空白和一对引号
{
    size_t n = wcslen(s), a = 0;
    while (n && (s[n - 1] == L' ' || s[n - 1] == L'\t' || s[n - 1] == L'\r' || s[n - 1] == L'\n')) s[--n] = 0;
    while (s[a] == L' ' || s[a] == L'\t') a++;
    if (a) { memmove(s, s + a, (n - a + 1) * sizeof(wchar_t)); n -= a; }
    if (n >= 2 && s[0] == L'"' && s[n - 1] == L'"') {
        memmove(s, s + 1, (n - 2) * sizeof(wchar_t));
        s[n - 2] = 0;
    }
}

static BOOL file_exists(const wchar_t *p)
{
    DWORD a = GetFileAttributesW(p);
    return a != INVALID_FILE_ATTRIBUTES && !(a & FILE_ATTRIBUTE_DIRECTORY);
}

// 追加到 dst；放不下返回 FALSE
static BOOL cat(wchar_t *dst, size_t cap, const wchar_t *s)
{
    size_t d = wcslen(dst), n = wcslen(s);
    if (d + n + 1 > cap) return FALSE;
    memcpy(dst + d, s, (n + 1) * sizeof(wchar_t));
    return TRUE;
}

static BOOL cat_quoted(wchar_t *dst, size_t cap, const wchar_t *s)
{
    return cat(dst, cap, L"\"") && cat(dst, cap, s) && cat(dst, cap, L"\"");
}

static void set_status(const wchar_t *t) { SetWindowTextW(g_status, t); }

static void append_log(const wchar_t *text)
{
    int len = GetWindowTextLengthW(g_log);
    if (len > 300000) { SetWindowTextW(g_log, L""); len = 0; }
    SendMessageW(g_log, EM_SETSEL, (WPARAM)len, (LPARAM)len);
    SendMessageW(g_log, EM_REPLACESEL, FALSE, (LPARAM)text);
    SendMessageW(g_log, EM_REPLACESEL, FALSE, (LPARAM)L"\r\n");
    SendMessageW(g_log, EM_SCROLLCARET, 0, 0);
}

/* ================= 配置文件 (wsub_gui.ini，与 exe 同目录) ================= */

static void cfg_get(const wchar_t *key, const wchar_t *def, wchar_t *out, DWORD cap)
{
    GetPrivateProfileStringW(L"cfg", key, def, out, cap, g_ini);
}

static void cfg_save(void)
{
    wchar_t b[PATHCAP];
    GetWindowTextW(g_edit[1], b, PATHCAP); clean_path(b); WritePrivateProfileStringW(L"cfg", L"model", b, g_ini);
    GetWindowTextW(g_edit[2], b, PATHCAP); clean_path(b); WritePrivateProfileStringW(L"cfg", L"vad", b, g_ini);
    GetWindowTextW(g_combo, b, 64);                        WritePrivateProfileStringW(L"cfg", L"lang", b, g_ini);
    GetWindowTextW(g_beam, b, 16);                         WritePrivateProfileStringW(L"cfg", L"beam", b, g_ini);
    GetWindowTextW(g_threads, b, 16);                      WritePrivateProfileStringW(L"cfg", L"threads", b, g_ini);
}

/* ================= 读取线程：管道 -> 界面 ================= */

typedef struct { HWND hwnd; HANDLE rd; HANDLE proc; } ReaderCtx;

static void handle_line(HWND hwnd, const char *line)
{
    if (strncmp(line, "@@PROGRESS ", 11) == 0) {
        PostMessageW(hwnd, WM_APP_PROGRESS, (WPARAM)atoi(line + 11), 0);
        return;
    }
    /* wsub 输出 UTF-8；ffmpeg 等外部程序的报错可能是系统 ANSI 代码页，先试 UTF-8，失败再回退 */
    UINT cp = CP_UTF8;
    DWORD flags = MB_ERR_INVALID_CHARS;
    int n = MultiByteToWideChar(cp, flags, line, -1, NULL, 0);
    if (n <= 0) {
        cp = CP_ACP; flags = 0;
        n = MultiByteToWideChar(cp, flags, line, -1, NULL, 0);
    }
    if (n <= 0) return;
    wchar_t *w = (wchar_t *)malloc((size_t)n * sizeof(wchar_t));
    if (!w) return;
    MultiByteToWideChar(cp, flags, line, -1, w, n);
    if (!PostMessageW(hwnd, WM_APP_LOG, 0, (LPARAM)w)) free(w);
}

static DWORD WINAPI reader_thread(LPVOID p)
{
    ReaderCtx *c = (ReaderCtx *)p;
    char buf[4096], line[8192];
    size_t ll = 0;
    DWORD got;

    /* 按行切分。不能把每次 ReadFile 的结果直接当一行：一个汉字的 3 个字节可能被拆在两次读取里 */
    while (ReadFile(c->rd, buf, sizeof buf, &got, NULL) && got > 0) {
        for (DWORD i = 0; i < got; i++) {
            char ch = buf[i];
            if (ch == '\n') {
                line[ll] = 0; handle_line(c->hwnd, line); ll = 0;
            } else if (ch != '\r') {
                line[ll++] = ch;
                if (ll >= sizeof line - 1) { line[ll] = 0; handle_line(c->hwnd, line); ll = 0; }
            }
        }
    }
    if (ll) { line[ll] = 0; handle_line(c->hwnd, line); }
    CloseHandle(c->rd);

    WaitForSingleObject(c->proc, INFINITE);
    DWORD code = 1;
    GetExitCodeProcess(c->proc, &code);
    CloseHandle(c->proc);

    PostMessageW(c->hwnd, WM_APP_DONE, (WPARAM)code, 0);
    free(c);
    return 0;
}

/* ================= 界面状态 ================= */

static void set_running(BOOL r)
{
    g_running = r;
    for (int i = 0; i < 3; i++) { EnableWindow(g_edit[i], !r); EnableWindow(g_btn[i], !r); }
    EnableWindow(g_combo, !r);
    EnableWindow(g_beam, !r);
    EnableWindow(g_threads, !r);
    EnableWindow(g_start, !r);
    EnableWindow(g_stop, r);
    if (r) EnableWindow(g_open, FALSE);
}

/* ================= 启动任务 ================= */

static void start_job(void)
{
    wchar_t in[PATHCAP], model[PATHCAP], vad[PATHCAP], out[PATHCAP];
    wchar_t lang[64], beamS[16], thrS[16], worker[PATHCAP], cmd[8192];

    GetWindowTextW(g_edit[0], in, PATHCAP);    clean_path(in);
    GetWindowTextW(g_edit[1], model, PATHCAP); clean_path(model);
    GetWindowTextW(g_edit[2], vad, PATHCAP);   clean_path(vad);
    GetWindowTextW(g_combo, lang, 64);         clean_path(lang);
    GetWindowTextW(g_beam, beamS, 16);
    GetWindowTextW(g_threads, thrS, 16);

    if (!file_exists(in))    { MessageBoxW(g_hwnd, L"输入文件不存在。", L"提示", MB_ICONWARNING); return; }
    if (!file_exists(model)) { MessageBoxW(g_hwnd, L"请选择有效的模型文件（ggml-*.bin）。", L"提示", MB_ICONWARNING); return; }
    if (vad[0] && !file_exists(vad)) { MessageBoxW(g_hwnd, L"VAD 模型文件不存在（可以留空）。", L"提示", MB_ICONWARNING); return; }
    if (!lang[0]) wcscpy(lang, L"auto");

    long beam = wcstol(beamS, NULL, 10), thr = wcstol(thrS, NULL, 10);
    if (beam < 0 || beam > 20) { MessageBoxW(g_hwnd, L"束宽请填 0~20（0 表示贪心）。", L"提示", MB_ICONWARNING); return; }
    if (thr < 1 || thr > 64)   { MessageBoxW(g_hwnd, L"线程数请填 1~64。", L"提示", MB_ICONWARNING); return; }

    /* worker 路径 */
    wcscpy(worker, g_dir);
    if (!cat(worker, PATHCAP, L"wsub.exe") || !file_exists(worker)) {
        MessageBoxW(g_hwnd, L"找不到 wsub.exe。\n请把它和本程序放在同一个文件夹里。", L"提示", MB_ICONWARNING);
        return;
    }

    // 输出路径：输入文件同名 .srt
    wcscpy(out, in);
    {
        wchar_t *dot = wcsrchr(out, L'.');
        wchar_t *s1 = wcsrchr(out, L'\\'), *s2 = wcsrchr(out, L'/');
        wchar_t *sep = (s1 > s2) ? s1 : s2;
        if (dot && (!sep || dot > sep)) *dot = 0;
        if (!cat(out, PATHCAP, L".srt")) { MessageBoxW(g_hwnd, L"路径太长。", L"提示", MB_ICONWARNING); return; }
    }
    if (file_exists(out)) {
        if (MessageBoxW(g_hwnd, L"字幕文件已存在，要覆盖吗？", L"确认", MB_YESNO | MB_ICONQUESTION) != IDYES) return;
    }

    /* 命令行 */
    cmd[0] = 0;
    BOOL ok = cat_quoted(cmd, 8192, worker) && cat(cmd, 8192, L" ") &&
              cat_quoted(cmd, 8192, in) && cat(cmd, 8192, L" ") &&
              cat_quoted(cmd, 8192, model) &&
              cat(cmd, 8192, L" -l ") && cat_quoted(cmd, 8192, lang) &&
              cat(cmd, 8192, L" -o ") && cat_quoted(cmd, 8192, out);
    {
        wchar_t tmp[64];
        _snwprintf(tmp, 64, L" --beam %ld -t %ld", beam, thr); tmp[63] = 0;
        ok = ok && cat(cmd, 8192, tmp);
    }
    if (vad[0]) ok = ok && cat(cmd, 8192, L" --vad ") && cat_quoted(cmd, 8192, vad);
    if (!ok) { MessageBoxW(g_hwnd, L"命令行太长。", L"提示", MB_ICONWARNING); return; }

    /* 匿名管道：子进程写，读取线程读 */
    SECURITY_ATTRIBUTES sa = { sizeof sa, NULL, TRUE };
    HANDLE rd = NULL, wr = NULL;
    if (!CreatePipe(&rd, &wr, &sa, 0)) { MessageBoxW(g_hwnd, L"创建管道失败。", L"错误", MB_ICONERROR); return; }
    SetHandleInformation(rd, HANDLE_FLAG_INHERIT, 0);   /* 读端不能被子进程继承，否则读不到 EOF */
    HANDLE nul = CreateFileW(L"NUL", GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, &sa, OPEN_EXISTING, 0, NULL);

    STARTUPINFOW si;
    PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof si);
    ZeroMemory(&pi, sizeof pi);
    si.cb          = sizeof si;
    si.dwFlags     = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    si.hStdInput   = nul;
    si.hStdOutput  = wr;
    si.hStdError   = wr;

    /* 先挂起创建，放进 Job 后再恢复，保证它的子进程（cmd/ffmpeg）也在 Job 里 */
    if (!CreateProcessW(worker, cmd, NULL, NULL, TRUE, CREATE_NO_WINDOW | CREATE_SUSPENDED, NULL, g_dir, &si, &pi)) {
        wchar_t msg[256];
        _snwprintf(msg, 256, L"启动 wsub.exe 失败（错误码 %lu）。", GetLastError()); msg[255] = 0;
        MessageBoxW(g_hwnd, msg, L"错误", MB_ICONERROR);
        CloseHandle(rd); CloseHandle(wr);
        if (nul != INVALID_HANDLE_VALUE) CloseHandle(nul);
        return;
    }
    CloseHandle(wr);     /* 父进程必须关掉自己的写端，管道才会在子进程退出时给出 EOF */
    if (nul != INVALID_HANDLE_VALUE) CloseHandle(nul);

    g_job = CreateJobObjectW(NULL, NULL);
    if (g_job) {
        JOBOBJECT_EXTENDED_LIMIT_INFORMATION jeli;
        ZeroMemory(&jeli, sizeof jeli);
        jeli.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
        SetInformationJobObject(g_job, JobObjectExtendedLimitInformation, &jeli, sizeof jeli);
        if (!AssignProcessToJobObject(g_job, pi.hProcess))
            append_log(L"[警告] 无法把任务放入 Job，取消时可能残留 ffmpeg 进程。");
    }
    ResumeThread(pi.hThread);
    CloseHandle(pi.hThread);

    ReaderCtx *rc = (ReaderCtx *)malloc(sizeof *rc);
    rc->hwnd = g_hwnd; rc->rd = rd; rc->proc = pi.hProcess;
    HANDLE th = CreateThread(NULL, 0, reader_thread, rc, 0, NULL);
    if (th) CloseHandle(th);

    cfg_save();
    wcscpy(g_lastOut, out);
    g_cancelled = FALSE;
    SetWindowTextW(g_log, L"");
    SendMessageW(g_prog, PBM_SETPOS, 0, 0);
    set_status(L"识别中 … 首次加载模型可能需要几十秒");
    set_running(TRUE);
}

static void stop_job(void)
{
    if (g_running && g_job) {
        g_cancelled = TRUE;
        TerminateJobObject(g_job, 1);
        set_status(L"正在取消 …");
    }
}

/* ================= 文件选择 ================= */

static void browse(int which)   /* 0 输入, 1 模型, 2 VAD */
{
    static const wchar_t *flt[3] = {
        L"音视频文件\0*.mp4;*.mkv;*.avi;*.mov;*.webm;*.flv;*.ts;*.mp3;*.wav;*.flac;*.m4a;*.aac;*.ogg;*.opus\0所有文件\0*.*\0",
        L"Whisper 模型 (*.bin)\0*.bin\0所有文件\0*.*\0",
        L"VAD 模型 (*.bin)\0*.bin\0所有文件\0*.*\0"
    };
    wchar_t file[PATHCAP];
    GetWindowTextW(g_edit[which], file, PATHCAP);
    clean_path(file);

    OPENFILENAMEW ofn;
    ZeroMemory(&ofn, sizeof ofn);
    ofn.lStructSize = sizeof ofn;
    ofn.hwndOwner   = g_hwnd;
    ofn.lpstrFilter = flt[which];
    ofn.lpstrFile   = file;
    ofn.nMaxFile    = PATHCAP;
    ofn.Flags       = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_EXPLORER | OFN_HIDEREADONLY;
    if (GetOpenFileNameW(&ofn)) SetWindowTextW(g_edit[which], file);
}

/* ================= 布局 ================= */

static void layout(void)
{
    RECT rc;
    GetClientRect(g_hwnd, &rc);
    int W = rc.right, H = rc.bottom;
    int m = S(12), lh = S(24), gap = S(8), lw = S(112), bw = S(84);
    int y = m;

    for (int i = 0; i < 3; i++) {
        MoveWindow(g_lbl[i],  m,            y + S(4), lw, lh, TRUE);
        MoveWindow(g_edit[i], m + lw,       y, W - 2 * m - lw - bw - gap, lh, TRUE);
        MoveWindow(g_btn[i],  W - m - bw,   y, bw, lh, TRUE);
        y += lh + gap;
    }

    int x = m;
    MoveWindow(g_lblLang, x, y + S(4), lw, lh, TRUE);                    x += lw;
    MoveWindow(g_combo,   x, y, S(100), S(220), TRUE);                   x += S(100) + S(24);
    MoveWindow(g_lblBeam, x, y + S(4), S(100), lh, TRUE);                x += S(100);
    MoveWindow(g_beam,    x, y, S(44), lh, TRUE);                        x += S(44) + S(24);
    MoveWindow(g_lblThr,  x, y + S(4), S(40), lh, TRUE);                 x += S(40);
    MoveWindow(g_threads, x, y, S(44), lh, TRUE);
    y += lh + gap + S(4);

    int bh = S(30);
    MoveWindow(g_start, m,                      y, S(110), bh, TRUE);
    MoveWindow(g_stop,  m + S(110) + gap,       y, S(90),  bh, TRUE);
    MoveWindow(g_open,  m + S(110) + S(90) + 2 * gap, y, S(120), bh, TRUE);
    y += bh + gap;

    MoveWindow(g_status, m, y, W - 2 * m, S(20), TRUE);  y += S(22);
    MoveWindow(g_prog,   m, y, W - 2 * m, S(18), TRUE);  y += S(18) + gap;
    MoveWindow(g_log,    m, y, W - 2 * m, H - y - m, TRUE);
}

/* ================= 创建控件 ================= */

static HWND mk(const wchar_t *cls, const wchar_t *txt, DWORD style, DWORD ex, int id)
{
    return CreateWindowExW(ex, cls, txt, WS_CHILD | WS_VISIBLE | style, 0, 0, 0, 0,
                           g_hwnd, (HMENU)(INT_PTR)id, GetModuleHandleW(NULL), NULL);
}

static BOOL CALLBACK set_font_proc(HWND h, LPARAM f)
{
    SendMessageW(h, WM_SETFONT, (WPARAM)f, TRUE);
    return TRUE;
}

static void create_controls(void)
{
    static const wchar_t *labels[3]  = { L"输入音视频", L"模型文件 (.bin)", L"VAD 模型（可选）" };
    static const int editIds[3] = { CID_IN_EDIT, CID_MODEL_EDIT, CID_VAD_EDIT };
    static const int btnIds[3]  = { CID_IN_BTN,  CID_MODEL_BTN,  CID_VAD_BTN };
    const DWORD EDIT_STYLE = WS_TABSTOP | ES_AUTOHSCROLL;

    for (int i = 0; i < 3; i++) {
        g_lbl[i]  = mk(L"STATIC", labels[i], SS_LEFT, 0, -1);
        g_edit[i] = mk(L"EDIT", L"", EDIT_STYLE, WS_EX_CLIENTEDGE, editIds[i]);
        g_btn[i]  = mk(L"BUTTON", L"浏览 …", WS_TABSTOP | BS_PUSHBUTTON, 0, btnIds[i]);
    }

    g_lblLang = mk(L"STATIC", L"语言", SS_LEFT, 0, -1);
    g_combo   = mk(L"COMBOBOX", L"", WS_TABSTOP | WS_VSCROLL | CBS_DROPDOWN | CBS_AUTOHSCROLL, 0, CID_LANG);
    {
        static const wchar_t *langs[] = { L"auto", L"zh", L"en", L"ja", L"ko", L"fr", L"de", L"es", L"ru", L"ar", L"pt", L"it" };
        for (size_t i = 0; i < sizeof langs / sizeof langs[0]; i++)
            SendMessageW(g_combo, CB_ADDSTRING, 0, (LPARAM)langs[i]);
    }
    g_lblBeam = mk(L"STATIC", L"束宽 (0=贪心)", SS_LEFT, 0, -1);
    g_beam    = mk(L"EDIT", L"5", WS_TABSTOP | ES_NUMBER | ES_AUTOHSCROLL, WS_EX_CLIENTEDGE, CID_BEAM);
    g_lblThr  = mk(L"STATIC", L"线程", SS_LEFT, 0, -1);
    g_threads = mk(L"EDIT", L"4", WS_TABSTOP | ES_NUMBER | ES_AUTOHSCROLL, WS_EX_CLIENTEDGE, CID_THREADS);

    g_start = mk(L"BUTTON", L"开始识别", WS_TABSTOP | BS_DEFPUSHBUTTON, 0, CID_START);
    g_stop  = mk(L"BUTTON", L"取消",     WS_TABSTOP | BS_PUSHBUTTON, 0, CID_STOP);
    g_open  = mk(L"BUTTON", L"定位字幕文件", WS_TABSTOP | BS_PUSHBUTTON, 0, CID_OPEN);

    g_status = mk(L"STATIC", L"就绪。可以把文件直接拖进窗口。", SS_LEFT | SS_ENDELLIPSIS, 0, CID_STATUS);
    g_prog   = mk(PROGRESS_CLASSW, L"", PBS_SMOOTH, 0, CID_PROGRESS);
    SendMessageW(g_prog, PBM_SETRANGE32, 0, 100);

    g_log = mk(L"EDIT", L"", WS_VSCROLL | ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | ES_NOHIDESEL,
               WS_EX_CLIENTEDGE, CID_LOG);
    SendMessageW(g_log, EM_LIMITTEXT, 1000000, 0);

    /* 字体：系统消息字体；日志用等宽字体 */
    NONCLIENTMETRICSW ncm;
    ZeroMemory(&ncm, sizeof ncm);
    ncm.cbSize = sizeof ncm;
    SystemParametersInfoW(SPI_GETNONCLIENTMETRICS, sizeof ncm, &ncm, 0);
    g_font = CreateFontIndirectW(&ncm.lfMessageFont);
    EnumChildWindows(g_hwnd, set_font_proc, (LPARAM)g_font);
    g_monoFont = CreateFontW(-S(12), 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                             OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
                             FIXED_PITCH | FF_MODERN, L"Consolas");
    if (g_monoFont) SendMessageW(g_log, WM_SETFONT, (WPARAM)g_monoFont, TRUE);
}

static void load_config(void)
{
    wchar_t b[PATHCAP];
    SYSTEM_INFO si;
    GetSystemInfo(&si);
    DWORD n = si.dwNumberOfProcessors;
    if (n < 1) n = 1;
    if (n > 8) n = 8;
    wchar_t def[16];
    _snwprintf(def, 16, L"%lu", n); def[15] = 0;

    cfg_get(L"model", L"", b, PATHCAP);   SetWindowTextW(g_edit[1], b);
    cfg_get(L"vad", L"", b, PATHCAP);     SetWindowTextW(g_edit[2], b);
    cfg_get(L"lang", L"auto", b, 64);     SetWindowTextW(g_combo, b);
    cfg_get(L"beam", L"5", b, 16);        SetWindowTextW(g_beam, b);
    cfg_get(L"threads", def, b, 16);      SetWindowTextW(g_threads, b);
}

/* ================= 窗口过程 ================= */

static LRESULT CALLBACK wnd_proc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
    switch (msg) {
    case WM_CREATE:
        g_hwnd = hwnd;
        {
            HDC dc = GetDC(NULL);
            g_dpi = GetDeviceCaps(dc, LOGPIXELSX);
            ReleaseDC(NULL, dc);
        }
        create_controls();
        load_config();
        set_running(FALSE);
        EnableWindow(g_open, FALSE);
        DragAcceptFiles(hwnd, TRUE);
        return 0;

    case WM_SIZE:
        if (g_log) layout();
        return 0;

    case WM_GETMINMAXINFO: {
        MINMAXINFO *mm = (MINMAXINFO *)lp;
        mm->ptMinTrackSize.x = S(620);
        mm->ptMinTrackSize.y = S(480);
        return 0;
    }

    case WM_DROPFILES: {
        wchar_t f[PATHCAP];
        if (!g_running && DragQueryFileW((HDROP)wp, 0, f, PATHCAP))
            SetWindowTextW(g_edit[0], f);
        DragFinish((HDROP)wp);
        return 0;
    }

    case WM_COMMAND:
        if (HIWORD(wp) == BN_CLICKED) {
            switch (LOWORD(wp)) {
            case CID_IN_BTN:    browse(0); break;
            case CID_MODEL_BTN: browse(1); break;
            case CID_VAD_BTN:   browse(2); break;
            case CID_START:     start_job(); break;
            case CID_STOP:      stop_job(); break;
            case CID_OPEN:
                if (g_lastOut[0]) {
                    wchar_t arg[PATHCAP + 16];
                    _snwprintf(arg, PATHCAP + 16, L"/select,\"%ls\"", g_lastOut);
                    arg[PATHCAP + 15] = 0;
                    ShellExecuteW(hwnd, L"open", L"explorer.exe", arg, NULL, SW_SHOWNORMAL);
                }
                break;
            }
        }
        return 0;

    case WM_APP_LOG:
        append_log((const wchar_t *)lp);
        free((void *)lp);
        return 0;

    case WM_APP_PROGRESS:
        SendMessageW(g_prog, PBM_SETPOS, wp, 0);
        {
            wchar_t t[64];
            _snwprintf(t, 64, L"识别中 … %d%%", (int)wp); t[63] = 0;
            if (g_running && !g_cancelled) set_status(t);
        }
        return 0;

    case WM_APP_DONE:
        if (g_job) { CloseHandle(g_job); g_job = NULL; }
        set_running(FALSE);
        if (g_cancelled) {
            set_status(L"已取消。");
            SendMessageW(g_prog, PBM_SETPOS, 0, 0);
        } else if (wp == 0) {
            set_status(L"完成！字幕已保存。");
            SendMessageW(g_prog, PBM_SETPOS, 100, 0);
            EnableWindow(g_open, TRUE);
        } else {
            wchar_t t[128];
            _snwprintf(t, 128, L"失败（退出码 %lu），请查看下方日志。", (unsigned long)wp); t[127] = 0;
            set_status(t);
        }
        return 0;

    case WM_CLOSE:
        if (g_running) {
            if (MessageBoxW(hwnd, L"正在识别，确定要退出吗？", L"确认", MB_YESNO | MB_ICONQUESTION) != IDYES)
                return 0;
            stop_job();
        }
        cfg_save();
        DestroyWindow(hwnd);
        return 0;

    case WM_DESTROY:
        if (g_job) { CloseHandle(g_job); g_job = NULL; }   /* KILL_ON_JOB_CLOSE：关窗口时一并结束子进程 */
        if (g_font) DeleteObject(g_font);
        if (g_monoFont) DeleteObject(g_monoFont);
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

/* ================= 入口 ================= */

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR cmdLine, int nShow)
{
    (void)hPrev; (void)cmdLine;

    INITCOMMONCONTROLSEX icc = { sizeof icc, ICC_PROGRESS_CLASS | ICC_STANDARD_CLASSES };
    InitCommonControlsEx(&icc);

    GetModuleFileNameW(NULL, g_dir, PATHCAP);
    wchar_t *sl = wcsrchr(g_dir, L'\\');
    if (sl) sl[1] = 0;
    wcscpy(g_ini, g_dir);
    cat(g_ini, PATHCAP, L"wsub_gui.ini");

    WNDCLASSEXW wc;
    ZeroMemory(&wc, sizeof wc);
    wc.cbSize        = sizeof wc;
    wc.lpfnWndProc   = wnd_proc;
    wc.hInstance     = hInst;
    wc.hCursor       = LoadCursorW(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    wc.lpszClassName = L"WsubGuiWindow";
    wc.hIcon         = LoadIconW(NULL, IDI_APPLICATION);
    if (!RegisterClassExW(&wc)) return 1;

    HDC dc = GetDC(NULL);
    int dpi = GetDeviceCaps(dc, LOGPIXELSX);
    ReleaseDC(NULL, dc);

    HWND hwnd = CreateWindowExW(0, wc.lpszClassName, L"字幕生成器",
                                WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
                                CW_USEDEFAULT, CW_USEDEFAULT,
                                MulDiv(760, dpi, 96), MulDiv(620, dpi, 96),
                                NULL, NULL, hInst, NULL);
    if (!hwnd) return 1;
    ShowWindow(hwnd, nShow);
    UpdateWindow(hwnd);

    MSG m;
    while (GetMessageW(&m, NULL, 0, 0) > 0) {
        if (!IsDialogMessageW(hwnd, &m)) {   //Tab切换
            TranslateMessage(&m);
            DispatchMessageW(&m);
        }
    }
    return (int)m.wParam;
}
