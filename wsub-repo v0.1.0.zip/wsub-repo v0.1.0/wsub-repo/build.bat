@echo off
rem Double-click friendly wrapper: runs build.ps1 and keeps the window open.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1"
echo.
if errorlevel 1 (echo Build failed. See the message above.) else (echo Build finished.)
pause
