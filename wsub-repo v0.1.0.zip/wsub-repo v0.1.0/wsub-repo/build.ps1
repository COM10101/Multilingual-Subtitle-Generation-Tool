# build.ps1 - build wsub.exe and wsub_gui.exe with MinGW-W64
# NOTE: this file is intentionally pure ASCII. Windows PowerShell 5.1 reads
# BOM-less files as the ANSI code page, which breaks non-ASCII text.
#
# Usage (from the repo root):   .\build.ps1
# Or just double-click build.bat
# Prerequisite: whisper.cpp already built, see README step 2.

$ErrorActionPreference = "Stop"

try {
    Set-Location -LiteralPath $PSScriptRoot

    foreach ($tool in @("gcc", "windres")) {
        if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) {
            throw "Cannot find '$tool'. Add the MinGW-W64 bin folder to PATH."
        }
    }

    $wc = "third_party/whisper.cpp"
    if (-not (Test-Path -LiteralPath "$wc/include/whisper.h")) {
        throw "Cannot find $wc/include/whisper.h . Put the whisper.cpp source in third_party/whisper.cpp (see README)."
    }

    # MinGW may name static libs 'libggml.a' or 'ggml.a'; accept both.
    function Find-Lib([string]$dir, [string[]]$names) {
        foreach ($n in $names) {
            $p = "$dir/$n"
            if (Test-Path -LiteralPath $p) { return $p }
        }
        throw "Static library not found in $dir (tried: $($names -join ', ')). Build whisper.cpp first (README step 2)."
    }

    $libs = @(
        (Find-Lib "$wc/build/src"      @("libwhisper.a", "whisper.a")),
        (Find-Lib "$wc/build/ggml/src" @("libggml.a", "ggml.a")),
        (Find-Lib "$wc/build/ggml/src" @("libggml-cpu.a", "ggml-cpu.a")),
        (Find-Lib "$wc/build/ggml/src" @("libggml-base.a", "ggml-base.a"))
    )

    New-Item -ItemType Directory -Force -Path "dist" | Out-Null
    New-Item -ItemType Directory -Force -Path "obj"  | Out-Null

    # Arguments containing a dot (like -Ithird_party/whisper.cpp/include) must be
    # quoted, otherwise PowerShell splits them at the dot.
    Write-Host "==> Building wsub.exe"
    & gcc -O2 -Wall "src/wsub.c" "-I$wc/include" "-I$wc/ggml/include" $libs -lstdc++ -lm -lpthread -fopenmp -o "dist/wsub.exe"
    if ($LASTEXITCODE -ne 0) { throw "wsub.exe build failed (gcc exit code $LASTEXITCODE)" }

    Write-Host "==> Building wsub_gui.exe"
    Push-Location "gui"
    try {
        & windres "wsub_gui.rc" -O coff -o "../obj/wsub_gui_res.o"
        if ($LASTEXITCODE -ne 0) { throw "resource build failed (windres exit code $LASTEXITCODE)" }
    } finally {
        Pop-Location
    }
    & gcc -O2 -Wall -mwindows "gui/wsub_gui.c" "obj/wsub_gui_res.o" -o "dist/wsub_gui.exe" -lcomctl32 -lcomdlg32 -lshell32 -lgdi32 -luser32
    if ($LASTEXITCODE -ne 0) { throw "wsub_gui.exe build failed (gcc exit code $LASTEXITCODE)" }

    Write-Host ""
    Write-Host "Done: dist\wsub.exe and dist\wsub_gui.exe"
}
catch {
    Write-Host ""
    Write-Host "BUILD FAILED:" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
