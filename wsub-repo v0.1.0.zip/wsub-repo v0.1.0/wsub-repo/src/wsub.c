/*
 * wsub.c - 音频/视频 -> SRT 字幕 (ffmpeg + whisper.cpp)
 *
 * 用法:
 *   wsub <输入文件> <ggml模型.bin> [选项]
 * 选项:
 *   -l <语言>     auto(默认)/zh/en/ja ...；音频语言不确定时务必用 auto
 *   -o <输出.srt> 默认与输入同名
 *   --vad <silero模型.bin>  启用语音活动检测，跳过静音/音乐/片尾空白
 *   --beam <N>    束搜索宽度，默认 5；0 = 贪心（更快，但更容易出错）
 *   -t <线程数>   默认 4
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "whisper.h"

#ifdef _WIN32
#define POPEN      _popen
#define PCLOSE     _pclose
#define POPEN_MODE "rb"   /* Windows: 必须二进制模式，否则字节 0x1A/0x0D0A 会被改写 */
#else
#define POPEN      popen
#define PCLOSE     pclose
#define POPEN_MODE "r"    /* Linux/macOS: popen 不接受 "b" */
#endif

/* ---------- 1. 用 ffmpeg 解码到内存 ---------- */
/* 成功返回样本数，失败返回 -1。*out 由调用者 free。 */
static long decode_audio(const char *path, float **out)
{
    char cmd[4096];
    /* -f f32le: 裸 float32 小端；pipe:1: 写到 stdout */
    int n = snprintf(cmd, sizeof cmd,
        "ffmpeg -nostdin -loglevel error -i \"%s\" -vn -ac 1 -ar 16000 -f f32le pipe:1",
        path);
    if (n < 0 || n >= (int)sizeof cmd) {
        fprintf(stderr, "路径太长\n");
        return -1;
    }

    FILE *p = POPEN(cmd, POPEN_MODE);
    if (!p) {
        fprintf(stderr, "无法启动 ffmpeg，请确认它在 PATH 里\n");
        return -1;
    }

    size_t cap = 1 << 20, len = 0;            /* 字节数 */
    unsigned char *buf = malloc(cap);
    if (!buf) { PCLOSE(p); return -1; }

    for (;;) {
        if (len == cap) {
            cap *= 2;
            unsigned char *nb = realloc(buf, cap);
            if (!nb) { free(buf); PCLOSE(p); return -1; }
            buf = nb;
        }
        size_t got = fread(buf + len, 1, cap - len, p);
        if (got == 0) break;
        len += got;
    }
    int rc = PCLOSE(p);
    if (rc != 0 || len < sizeof(float)) {
        fprintf(stderr, "ffmpeg 解码失败（退出码 %d，读到 %zu 字节）\n", rc, len);
        free(buf);
        return -1;
    }

    *out = (float *)buf;          /* malloc 的内存满足 float 对齐 */
    return (long)(len / sizeof(float));
}

/* ---------- 2. SRT 时间戳 ---------- */
/* whisper 的时间单位是 10 毫秒 */
static void fmt_ts(char *dst, size_t n, int64_t t10ms)
{
    int64_t ms = t10ms * 10;
    int h = (int)(ms / 3600000); ms %= 3600000;
    int m = (int)(ms / 60000);   ms %= 60000;
    int s = (int)(ms / 1000);
    int r = (int)(ms % 1000);
    snprintf(dst, n, "%02d:%02d:%02d,%03d", h, m, s, r);
}

/* 去掉首尾空白，返回新的起点 */
static const char *trim(const char *s, size_t *len)
{
    size_t l = strlen(s);
    while (l && (s[l - 1] == ' ' || s[l - 1] == '\n' || s[l - 1] == '\r' || s[l - 1] == '\t')) l--;
    while (l && (*s == ' ' || *s == '\n' || *s == '\r' || *s == '\t')) { s++; l--; }
    *len = l;
    return s;
}

/* ---------- 进度回调：每变化 1% 输出一行，供图形界面解析 ---------- */
static void on_progress(struct whisper_context *ctx, struct whisper_state *state,
                        int progress, void *user_data)
{
    (void)ctx; (void)state;
    int *last = (int *)user_data;
    if (progress != *last) {
        *last = progress;
        printf("@@PROGRESS %d\n", progress);
        fflush(stdout);
    }
}

int main(int argc, char **argv)
{
    /* 输出被管道接走时 stdout 默认是全缓冲，界面会长时间收不到任何内容 → 关闭缓冲 */
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    if (argc < 3) {
        fprintf(stderr, "用法: %s <输入音视频> <ggml模型.bin> [-l 语言] [-o 输出.srt] "
                        "[--vad vad模型.bin] [--beam N] [-t 线程数]\n", argv[0]);
        return 1;
    }
    const char *in_path    = argv[1];
    const char *model_path = argv[2];
    const char *lang       = "auto";
    const char *vad_path   = NULL;
    const char *out_arg    = NULL;
    int beam = 5, threads = 4;

    for (int i = 3; i < argc; i++) {
        int has_val = i + 1 < argc;
        if      (!strcmp(argv[i], "-l")     && has_val) lang     = argv[++i];
        else if (!strcmp(argv[i], "-o")     && has_val) out_arg  = argv[++i];
        else if (!strcmp(argv[i], "--vad")  && has_val) vad_path = argv[++i];
        else if (!strcmp(argv[i], "--beam") && has_val) beam     = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-t")     && has_val) threads  = atoi(argv[++i]);
        else { fprintf(stderr, "无法识别的参数: %s\n", argv[i]); return 1; }
    }

    char out_path[4096];
    if (out_arg) {
        snprintf(out_path, sizeof out_path, "%s", out_arg);
    } else {
        snprintf(out_path, sizeof out_path, "%s", in_path);
        char *dot = strrchr(out_path, '.');
        char *sep = strrchr(out_path, '/');
        char *bs  = strrchr(out_path, '\\');
        if (bs > sep) sep = bs;
        if (dot && (!sep || dot > sep)) *dot = '\0';
        strncat(out_path, ".srt", sizeof out_path - strlen(out_path) - 1);
    }

    /* 1. 解码音频 */
    printf("1/3 ffmpeg 解码音频 ...\n");
    float *pcm = NULL;
    long n_samples = decode_audio(in_path, &pcm);
    if (n_samples < 0) return 2;
    printf("    %ld 个样本，约 %.1f 秒\n", n_samples, n_samples / 16000.0);

    /* 2. 加载模型 */
    printf("2/3 加载模型 %s\n", model_path);
    struct whisper_context_params cparams = whisper_context_default_params();
    cparams.use_gpu = 1;  /* 库是否带 GPU 后端取决于你编译 whisper.cpp 时的开关 */
    struct whisper_context *ctx = whisper_init_from_file_with_params(model_path, cparams);
    if (!ctx) {
        fprintf(stderr, "模型加载失败: %s\n", model_path);
        free(pcm);
        return 3;
    }
    printf("    %s\n", whisper_print_system_info());

    /* 3. 识别 */
    printf("3/3 识别中 ...\n");
    struct whisper_full_params wp = beam > 0
        ? whisper_full_default_params(WHISPER_SAMPLING_BEAM_SEARCH)
        : whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    if (beam > 0) wp.beam_search.beam_size = beam;
    wp.language         = lang;      /* "auto" = 自动检测 */
    wp.n_threads        = threads;
    wp.translate        = 0;
    wp.no_context       = 1;         /* 不把上一段文字当提示：防止错误一路传染、陷入重复 */
    wp.suppress_blank   = 1;
    wp.suppress_nst     = 1;         /* 抑制 [音乐] 之类的非语音标记 */
    wp.print_progress   = 0;
    wp.print_realtime   = 0;
    wp.print_timestamps = 0;
    wp.print_special    = 0;
    int last_progress = -1;
    wp.progress_callback           = on_progress;
    wp.progress_callback_user_data = &last_progress;
    if (vad_path) {
        wp.vad            = 1;
        wp.vad_model_path = vad_path;
        wp.vad_params     = whisper_vad_default_params();
        printf("    已启用 VAD: %s\n", vad_path);
    }
    printf("    语言=%s 束宽=%d 线程=%d\n", lang, beam, threads);

    if (whisper_full(ctx, wp, pcm, (int)n_samples) != 0) {
        fprintf(stderr, "whisper_full 失败\n");
        whisper_free(ctx);
        free(pcm);
        return 4;
    }

    printf("    检测到的语言: %s\n", whisper_lang_str(whisper_full_lang_id(ctx)));

    /* 4. 写 SRT */
    FILE *fo = fopen(out_path, "wb");
    if (!fo) {
        fprintf(stderr, "无法写入 %s\n", out_path);
        whisper_free(ctx);
        free(pcm);
        return 5;
    }
    int n_seg = whisper_full_n_segments(ctx), count = 0, dup = 0;
    const char *prev = NULL; size_t prev_len = 0;
    for (int i = 0; i < n_seg; i++) {
        size_t tl;
        const char *text = trim(whisper_full_get_segment_text(ctx, i), &tl);
        if (tl == 0) continue;
        /* 兜底：与上一条完全相同的文字直接丢弃 */
        if (prev && tl == prev_len && memcmp(text, prev, tl) == 0) { dup++; continue; }
        prev = text; prev_len = tl;
        char a[32], b[32];
        fmt_ts(a, sizeof a, whisper_full_get_segment_t0(ctx, i));
        fmt_ts(b, sizeof b, whisper_full_get_segment_t1(ctx, i));
        count++;
        fprintf(fo, "%d\n%s --> %s\n%.*s\n\n", count, a, b, (int)tl, text);
        printf("[%s] %.*s\n", a, (int)tl, text);
    }
    fclose(fo);
    printf("@@PROGRESS 100\n");
    printf("\n完成: %d 条字幕 -> %s（丢弃连续重复 %d 条）\n", count, out_path, dup);

    whisper_free(ctx);
    free(pcm);
    return 0;
}
